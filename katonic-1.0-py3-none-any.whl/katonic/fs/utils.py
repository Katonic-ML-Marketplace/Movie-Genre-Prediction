import os
from datetime import datetime

import re
from pytz import utc


def make_tzaware(t: datetime) -> datetime:
    """ We assume tz-naive datetimes are UTC """
    return t.replace(tzinfo=utc) if t.tzinfo is None else t

def is_valid_name(name: str) -> bool:
    """A name should be alphanumeric values and underscores but not start with an underscore"""
    return not name.startswith("_") and re.compile(r"\W+").search(name) is None

# set environment variable
os.environ['DB_NAME'] = 'c3BhcmtkYg=='

os.environ['HOST'] = 'cG9zdGdyZXMtc2VydmljZS5hcHBsaWNhdGlvbg=='

os.environ['USER'] = 'cG9zdGdyZXM='

os.environ['POSTGRES_PASSWORD'] = 'cG9zdGdyZXMxMjM='

os.environ['DB_SCHEMA'] = 'cHVibGlj'

os.environ['REDIS_HOST'] = 'cmVkaXMtbWFzdGVyLmFwcGxpY2F0aW9u'

os.environ['REDIS_PASSWORD'] = 'cmVkaXMxMjM='