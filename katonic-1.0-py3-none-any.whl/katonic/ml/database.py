import psycopg2
import pandas as pd
from sqlalchemy import create_engine,text
from typing import Optional

POSTGRES_ADDRESS = '52.187.120.22' ## INSERT YOUR DB ADDRESS
POSTGRES_PORT = '5432'
POSTGRES_USERNAME = 'postgres' ## CHANGE THIS TO YOUR POSTGRES USERNAME
POSTGRES_PASSWORD = 'katonic@47'.replace("@","%40") ## CHANGE THIS TO YOUR POSTGRES PASSWORD POSTGRES_DBNAME = 'database' ## CHANGE THIS TO YOUR DATABASE NAME
POSTGRES_DBNAME = 'postgres' ## CHANGE THIS TO YOUR DATABASE NAME
POSTGRES_ENGINE = 'postgres'

def write_to_table(PROJECT_SCHEMA,dataset,table):
    '''
    This Function writes data to the provided postgres table under project schema.

    Args:
        PROJECT_SCHEMA (str): a postgres schema under which provided table will create.
        dataset (pd.DataFrame): a pandas dataframe to be write in the postgres.
        table (str): postgres table name.
    '''
    postgres_str = (f"postgresql+psycopg2://{POSTGRES_USERNAME}:{POSTGRES_PASSWORD}@{POSTGRES_ADDRESS}:{POSTGRES_PORT}/{POSTGRES_DBNAME}")
    engine = create_engine(postgres_str)
    
    query = text(f""" 
                CREATE SCHEMA IF NOT EXISTS {PROJECT_SCHEMA} """)
    engine.execute(query)
    
    dataset.to_sql(table, con=engine, schema=PROJECT_SCHEMA, index=False,if_exists='append',method='multi')
    engine.dispose()
    
def read_from_table(PROJECT_SCHEMA,table):
    '''
    This Function reads data from the provided postgres table lies in project schema.

    Args:
        PROJECT_SCHEMA (str): a postgres schema under which provided table is exist.
        table (str): postgres table name from which you want to read data.
    '''
    postgres_str = (f"postgresql+psycopg2://{POSTGRES_USERNAME}:{POSTGRES_PASSWORD}@{POSTGRES_ADDRESS}:{POSTGRES_PORT}/{POSTGRES_DBNAME}")
    engine = create_engine(postgres_str)
    df = pd.read_sql('SELECT * FROM {0}.{1}'.format(PROJECT_SCHEMA, table), engine)
    engine.dispose()
    return df  

def truncate_table(PROJECT_SCHEMA,table):
    '''
    This Function truncate/delete data from the provided postgres table lies in project schema.

    Args:
        PROJECT_SCHEMA (str): a postgres schema under which provided table is exist.
        table (str): postgres table name, which you want to delete/truncate.
    '''
    postgres_str = (f"postgresql+psycopg2://{POSTGRES_USERNAME}:{POSTGRES_PASSWORD}@{POSTGRES_ADDRESS}:{POSTGRES_PORT}/{POSTGRES_DBNAME}")
    engine = create_engine(postgres_str)
    pd.read_sql('TRUNCATE {0}.{1}'.format(PROJECT_SCHEMA, table), engine)
    engine.dispose()